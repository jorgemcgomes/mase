package ec.neat;

import ec.vector.*;
import ec.*;
import ec.util.*;
import java.util.*;

/**
 * NEATSpecies is a GeneVectorSpecies which implements NEAT algorithm. The class
 * has several important methods. The breedNewPopulation(...) will first use the
 * methods in this class to determined the expected offsprings for each of the
 * subspecies, then call the reproduce of each subspecies to reproduce new
 * individuals. After one individual is created, we call speciate(...) in this
 * class to assign it to a subspecies, this could lead to creation of new
 * subspecies.
 * 
 * <p>
 * NEATSpecies must be used in combination with NEATBreeder, which will call it
 * at appropriate times to reproduce new individuals for next generations. It
 * must also be used in combination with NEATInitializer, which will use it to
 * generate the initial population.
 *
 *
 * 
 * 
 * <p>
 * <b>Parameters</b><br>
 * <table>
 * <tr>
 * <td valign=top><tt><i>base</i>.weight-mut-power</tt><br>
 * <font size=-1>Floating-point value (default is 2.5)</font></td>
 * <td valign=top>Mutation power of the link weights</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.disjoint-coeff</tt><br>
 * <font size=-1>Floating-point value (default is 1.0)</font></td>
 * <td valign=top>Coefficient for disjoint gene in compatibility computation
 * </td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.excess-coeff</tt><br>
 * <font size=-1>Floating-point value (default is 1.0)</font></td>
 * <td valign=top>Coefficient for excess genes in compatibility computation</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.mutdiff-coeff</tt><br>
 * <font size=-1>Floating-point value (default is 0.4)</font></td>
 * <td valign=top>Coefficient for mutational difference genes in compatibility
 * computation</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.compat-thresh</tt><br>
 * <font size=-1>Floating-point value (default is 3.0)</font></td>
 * <td valign=top>Compatible threshold to determine if two individual are
 * compatible</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.age-significance</tt><br>
 * <font size=-1>Floating-point value (default is 1.0)</font></td>
 * <td valign=top>How much does age matter?</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.survival-thresh</tt><br>
 * <font size=-1>Floating-point value (default is 0.2)</font></td>
 * <td valign=top>Percent of ave fitness for survival</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.mutate-only-prob</tt><br>
 * <font size=-1>Floating-point value (default is 0.25)</font></td>
 * <td valign=top>Probability of a non-mating reproduction</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.mutate-link-weight-prob</tt><br>
 * <font size=-1>Floating-point value (default is 0.9)</font></td>
 * <td valign=top>Probability of doing link weight mutate</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.mutate-toggle-enable-prob</tt><br>
 * <font size=-1>Floating-point value (default is 0.0)</font></td>
 * <td valign=top>Probability of changing the enable status of gene</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.mutate-gene-reenable-prob</tt><br>
 * <font size=-1>Floating-point value (default is 0.0)</font></td>
 * <td valign=top>Probability of reenable a disabled gene</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.mutate-add-node-prob</tt><br>
 * <font size=-1>Floating-point value (default is 0.03)</font></td>
 * <td valign=top>Probability of doing add-node mutation</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.mutate-add-link-prob</tt><br>
 * <font size=-1>Floating-point value (default is 0.05)</font></td>
 * <td valign=top>Probability of doing add-link mutation</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.interspecies-mate-prob</tt><br>
 * <font size=-1>Floating-point value (default is 0.001)</font></td>
 * <td valign=top>Probability of doing interspecies crossover</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.mate-multipoint-prob</tt><br>
 * <font size=-1>Floating-point value (default is 0.6)</font></td>
 * <td valign=top>Probability of doing multipoint crossover</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.mate-multipoint-avg-prob</tt><br>
 * <font size=-1>Floating-point value (default is 0.4)</font></td>
 * <td valign=top>Probability of doing multipoint crossover with averaging two
 * genes</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.mate-singlepoint-prob</tt><br>
 * <font size=-1>Floating-point value (default is 0.0)</font></td>
 * <td valign=top>Probability of doing single point crossover (not in used in
 * this implementation, always set to 0)</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.mate-only-prob</tt><br>
 * <font size=-1>Floating-point value (default is 0.2)</font></td>
 * <td valign=top>Probability of mating without mutation</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.recur-only-prob</tt><br>
 * <font size=-1>Floating-point value (default is 0.2)</font></td>
 * <td valign=top>Probability of forcing selection of ONLY links that are
 * naturally recurrent</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.dropoff-age</tt><br>
 * <font size=-1>Integer (default is 15)</font></td>
 * <td valign=top>Age where Species starts to be penalized</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.newlink-tries</tt><br>
 * <font size=-1>Integer (default is 20)</font></td>
 * <td valign=top>Number of tries mutateAddLink will attempt to find an open
 * link</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.babies-stolen</tt><br>
 * <font size=-1>Integer (default is 0)</font></td>
 * <td valign=top>The number of babies to siphen off to the champions</td>
 * </tr>
 * <tr>
 * <td valign=top><tt><i>base</i>.debug-info</tt><br>
 * <font size=-1>Boolean (default = false)</font></td>
 * <td valign=top>Do we want to turn on some print statement?</td>
 * </tr>
 * <tr>
 * <td valign=top><i>base</i>.<tt>node</tt><br>
 * <font size=-1>Classname, = ec.neat.NEATNode</font></td>
 * <td valign=top>Class of node in a network</td>
 * </tr>
 * <tr>
 * <td valign=top><i>base</i>.<tt>subspecies</tt><br>
 * <font size=-1>Classname, = ec.neat.NEATSubspecies</font></td>
 * <td valign=top>Class of subspecies in the species</td>
 * </tr>
 * <tr>
 * <td valign=top><i>base</i>.<tt>innovation</tt><br>
 * <font size=-1>Classname, = ec.neat.NEATInnovation</font></td>
 * <td valign=top>Class of innovation in the species</td>
 * </tr>
 * </table>
 * 
 * 
 * 
 * <p>
 * <b>Default Base</b><br>
 * neat.species
 * 
 * <p>
 * <b>Parameter bases</b><br>
 * <table>
 * <tr>
 * <td valign=top><i>base</i>.<tt>species</tt></td>
 * <td>species (the subpopulations' species)</td>
 * </tr>
 *
 *
 * 
 * @author Ermo Wei and David Freelan
 * 
 */
public class NEATSpecies extends GeneVectorSpecies
    {

    public enum MutationType
        {
        GAUSSIAN, COLDGAUSSIAN
            }

    // trait parameters
    public static final String P_TRAITPARAMMUTATEPROB = "trait-param-mutate-prob";
    public static final String P_TRAITMUTATIONPOWER = "trait-mutation-power";
    public static final String P_LINKTRAITMUTATESIG = "linktrait-mutate-sig";
    public static final String P_NODETRAITMUTATESIG = "nodetrait-mutate-sig";
    public static final String P_MUTATERANDOMTRAITPROB = "mutate-random-trait-prob";
    public static final String P_MUTATELINKTRAITPROB = "mutate-link-trait-prob";
    public static final String P_MUTATENODETRAITPROB = "mutate-node-trait-prob";
    public static final String P_NUMTRAITPARAMS = "num-trait-params";

    // parameters
    public static final String P_SPECIES = "species";
    public static final String P_NODE = "node";
    public static final String P_SUBSPECIES = "subspecies";
    public static final String P_INNOVATION = "innovation";
    public static final String P_WEIGHTMUTPOWER = "weight-mut-power";
    public static final String P_DISJOINTCOEFF = "disjoint-coeff";
    public static final String P_EXCESSCOEFF = "excess-coeff";
    public static final String P_MUTDIFFCOEFF = "mutdiff-coeff";
    public static final String P_COMPATTHRESH = "compat-thresh";
    public static final String P_AGESIGNIFICANCE = "age-significance";
    public static final String P_SURVIVIALTHRESH = "survival-thresh";
    public static final String P_MUTATEONLYPROB = "mutate-only-prob";
    public static final String P_MUTATELINKWEIGHTPROB = "mutate-link-weight-prob";
    public static final String P_MUTATETOGGLEENABLEPROB = "mutate-toggle-enable-prob";
    public static final String P_MUTATEGENEREENABLEPROB = "mutate-gene-reenable-prob";
    public static final String P_MUTATEADDNODEPROB = "mutate-add-node-prob";
    public static final String P_MUTATEADDLINKPROB = "mutate-add-link-prob";
    public static final String P_INTERSPECIESMATEPROB = "interspecies-mate-prob";
    public static final String P_MATEMULTIPOINTPROB = "mate-multipoint-prob";
    public static final String P_MATEMULTIPOINTAVGPROB = "mate-multipoint-avg-prob";
    public static final String P_MATESINGLEPOINTPROB = "mate-singlepoint-prob";
    public static final String P_MATEONLYPROB = "mate-only-prob";
    public static final String P_RECURONLYPROB = "recur-only-prob";
    public static final String P_DROPOFFAGE = "dropoff-age";
    public static final String P_NEWLINKTRIES = "newlink-tries";
    public static final String P_BABIESSTOLEN = "babies-stolen";
    public static final String P_DEBUGINFO = "debug-info";

    /** The prototypical node for individuals in this species. */
    public NEATNode nodePrototype;

    /** The prototypical subspecies for individuals in this species. */
    public NEATSubspecies subspeciesPrototype;

    /** The prototypical innovation for individuals in this species. */
    public NEATInnovation innovationPrototype;

    /** Current node id that is available. */
    private int currNodeId;

    /** Current innovation number that is available. */
    private int currInnovNum;
    
    Object innovLock = new Object[0];
    public int nextInnovNum() { synchronized(innovLock) { return ++currInnovNum; } }

    /** Used for delta coding, stagnation detector. */
    public double highestFitness;

    /** Used for delta coding, If too high, leads to delta coding. */
    public int highestLastChanged;

    // Trait parameters start
    /** Trait parameter, not use in current implementation. */
    public double traitParamMutateProb;

    /** Trait parameter, not use in current implementation. */
    public double traitMutationPower;

    /** Trait parameter, not use in current implementation. */
    public double linkTraitMutateSig;

    /** Trait parameter, not use in current implementation. */
    public double nodeTraitMutateSig;

    /** Trait parameter, not use in current implementation. */
    public double mutateRandomTraitProb;

    /** Trait parameter, not use in current implementation. */
    public double mutateLinkTraitProb;

    /** Trait parameter, not use in current implementation. */
    public double mutateNodeTraitProb;

    /** Trait parameter, not use in current implementation. */
    public int numTraitParams;
    // Trait parameters end

    /** The Mutation power of the link's weights. */
    public double weightMutationPower;

    /** Coefficient for disjoint gene in compatibility computation. */
    public double disjointCoeff;

    /** Coefficient for excess genes in compatibility computation. */
    public double excessCoeff;

    /**
     * Coefficient for mutational difference genes in compatibility computation.
     */
    public double mutDiffCoeff;

    /** Compatible threshold to determine if two individual are compatible. */
    public double compatThreshold;

    /** How much does age matter? */
    public double ageSignificance;

    /** Percent of ave fitness for survival. */
    public double survivalThreshold;

    /** Probility of a non-mating reproduction. */
    public double mutateOnlyProb;

    /** Probability of doing link weight mutate. */
    public double mutateLinkWeightsProb;

    /** Probability of changing the enable status of gene. */
    public double mutateToggleEnableProb;

    /** Probability of reenable a disabled gene. */
    public double mutateGeneReenableProb;

    /** Probability of doing add-node mutation. */
    public double mutateAddNodeProb;

    /** Probability of doing add-link mutation. */
    public double mutateAddLinkProb;

    /** Probability of doing interspecies crossover. */
    public double interspeciesMateRate;

    /** Probability of doing multipoint crossover. */
    public double mateMultipointProb;

    /** Probability of doing multipoint crossover with averaging two genes. */
    public double mateMultipointAvgProb;

    /**
     * Probability of doing single point crossover (not in used in this
     * implementation, always set to 0).
     */
    public double mateSinglepointProb;

    /** Probability of mating without mutation. */
    public double mateOnlyProb;

    /**
     * Probability of forcing selection of ONLY links that are naturally
     * recurrent.
     */
    public double recurOnlyProb;

    /** Age where Species starts to be penalized. */
    public int dropoffAge;

    /** Number of tries mutateAddLink will attempt to find an open link. */
    public int newLinkTries;

    /** The number of babies to siphen off to the champions. */
    public int babiesStolen;

    /** If we are in debug mode, this will trigger some print statement. */
    public boolean debugInfo;

    public Parameter base;

    /** A list of the all the subspecies. */
    public ArrayList<NEATSubspecies> subspecies;

    /** A Hashmap for easy tracking the innovation within species. */
    public HashMap<NEATInnovation, NEATInnovation> innovations;

    public void setup(final EvolutionState state, final Parameter base)
        {
        Parameter def = defaultBase();

        nodePrototype = (NEATNode) (state.parameters.getInstanceForParameterEq(base.push(P_NODE), def.push(P_NODE),
                NEATNode.class));
        nodePrototype.setup(state, base.push(P_NODE));

        subspeciesPrototype = (NEATSubspecies) (state.parameters.getInstanceForParameterEq(base.push(P_SUBSPECIES),
                def.push(P_SUBSPECIES), NEATSubspecies.class));
        subspeciesPrototype.setup(state, base.push(P_SUBSPECIES));

        innovationPrototype = (NEATInnovation) (state.parameters.getInstanceForParameterEq(base.push(P_INNOVATION),
                def.push(P_INNOVATION), NEATInnovation.class));
        subspeciesPrototype.setup(state, base.push(P_INNOVATION));

        // make sure that super.setup is done AFTER we've loaded our gene
        // prototype.
        super.setup(state, base);

        subspecies = new ArrayList<NEATSubspecies>();
        innovations = new HashMap<NEATInnovation, NEATInnovation>();
        highestFitness = 0;
        highestLastChanged = 0;

        // Load trait parameters from parameter file
        traitParamMutateProb = state.parameters.getDouble(base.push(P_TRAITPARAMMUTATEPROB),
            def.push(P_TRAITPARAMMUTATEPROB), 0.5);
        traitMutationPower = state.parameters.getDouble(base.push(P_TRAITMUTATIONPOWER), def.push(P_TRAITMUTATIONPOWER),
            1.0);
        linkTraitMutateSig = state.parameters.getDouble(base.push(P_LINKTRAITMUTATESIG), def.push(P_LINKTRAITMUTATESIG),
            1.0);
        nodeTraitMutateSig = state.parameters.getDouble(base.push(P_NODETRAITMUTATESIG), def.push(P_NODETRAITMUTATESIG),
            0.5);
        mutateRandomTraitProb = state.parameters.getDouble(base.push(P_MUTATERANDOMTRAITPROB),
            def.push(P_MUTATERANDOMTRAITPROB), 0.1);
        mutateLinkTraitProb = state.parameters.getDouble(base.push(P_MUTATELINKTRAITPROB),
            def.push(P_MUTATELINKTRAITPROB), 0.1);
        mutateNodeTraitProb = state.parameters.getDouble(base.push(P_MUTATENODETRAITPROB),
            def.push(P_MUTATENODETRAITPROB), 0.1);
        numTraitParams = state.parameters.getInt(base.push(P_NUMTRAITPARAMS), def.push(P_NUMTRAITPARAMS), 8);

        // Load parameters from the parameter file
        weightMutationPower = state.parameters.getDouble(base.push(P_WEIGHTMUTPOWER), def.push(P_WEIGHTMUTPOWER), 2.5);
        disjointCoeff = state.parameters.getDouble(base.push(P_DISJOINTCOEFF), def.push(P_DISJOINTCOEFF), 1.0);
        excessCoeff = state.parameters.getDouble(base.push(P_EXCESSCOEFF), def.push(P_EXCESSCOEFF), 1.0);
        mutDiffCoeff = state.parameters.getDouble(base.push(P_MUTDIFFCOEFF), def.push(P_MUTDIFFCOEFF), 0.4);
        compatThreshold = state.parameters.getDouble(base.push(P_COMPATTHRESH), def.push(P_COMPATTHRESH), 3.0);
        ageSignificance = state.parameters.getDouble(base.push(P_AGESIGNIFICANCE), def.push(P_AGESIGNIFICANCE), 1.0);
        survivalThreshold = state.parameters.getDouble(base.push(P_SURVIVIALTHRESH), def.push(P_SURVIVIALTHRESH), 0.2);
        mutateOnlyProb = state.parameters.getDouble(base.push(P_MUTATEONLYPROB), def.push(P_MUTATEONLYPROB), 0.25);
        mutateLinkWeightsProb = state.parameters.getDouble(base.push(P_MUTATELINKWEIGHTPROB),
            def.push(P_MUTATELINKWEIGHTPROB), 0.9);
        mutateToggleEnableProb = state.parameters.getDouble(base.push(P_MUTATETOGGLEENABLEPROB),
            def.push(P_MUTATETOGGLEENABLEPROB), 0.0);
        mutateGeneReenableProb = state.parameters.getDouble(base.push(P_MUTATEGENEREENABLEPROB),
            def.push(P_MUTATEGENEREENABLEPROB), 0.0);
        mutateAddNodeProb = state.parameters.getDouble(base.push(P_MUTATEADDNODEPROB), def.push(P_MUTATEADDNODEPROB),
            0.03);
        mutateAddLinkProb = state.parameters.getDouble(base.push(P_MUTATEADDLINKPROB), def.push(P_MUTATEADDLINKPROB),
            0.05);
        interspeciesMateRate = state.parameters.getDouble(base.push(P_INTERSPECIESMATEPROB),
            def.push(P_INTERSPECIESMATEPROB), 0.001);
        mateMultipointProb = state.parameters.getDouble(base.push(P_MATEMULTIPOINTPROB), def.push(P_MATEMULTIPOINTPROB),
            0.6);
        mateMultipointAvgProb = state.parameters.getDouble(base.push(P_MATEMULTIPOINTAVGPROB),
            def.push(P_MATEMULTIPOINTAVGPROB), 0.4);
        mateSinglepointProb = state.parameters.getDouble(base.push(P_MATESINGLEPOINTPROB),
            def.push(P_MATESINGLEPOINTPROB), 0.0);
        mateOnlyProb = state.parameters.getDouble(base.push(P_MATEONLYPROB), def.push(P_MATEONLYPROB), 0.2);
        recurOnlyProb = state.parameters.getDouble(base.push(P_RECURONLYPROB), def.push(P_RECURONLYPROB), 0.0);
        dropoffAge = state.parameters.getInt(base.push(P_DROPOFFAGE), def.push(P_DROPOFFAGE), 15);
        newLinkTries = state.parameters.getInt(base.push(P_NEWLINKTRIES), def.push(P_NEWLINKTRIES), 20);
        babiesStolen = state.parameters.getInt(base.push(P_BABIESSTOLEN), def.push(P_BABIESSTOLEN), 0);
        debugInfo = state.parameters.getBoolean(base.push(P_DEBUGINFO), base.push(P_DEBUGINFO), false);

        }

    public Parameter defaultBase()
        {
        return NEATDefaults.base().push(P_SPECIES);
        }
   
    /** Assign the individual into a species, if not found, create a new one */
    public void speciate(EvolutionState state, Individual ind)
        {
       
        NEATIndividual neatInd = (NEATIndividual) ind;
        // For each individual, search for a subspecies it is compatible to
        if (subspecies.size() == 0) // not subspecies available, create the
            // first species
            {
            NEATSubspecies newSubspecies = (NEATSubspecies) subspeciesPrototype.emptyClone();
            newSubspecies.reset();
            subspecies.add(newSubspecies);
            newSubspecies.addNewGenIndividual(neatInd);
            }
        else
            {
            boolean found = false;
            for (int i = 0; i < subspecies.size(); ++i)
                {
                NEATIndividual represent = (NEATIndividual) subspecies.get(i).newGenerationFirst();
		if (represent == null)
                    represent = (NEATIndividual) subspecies.get(i).first();

                // found compatible subspecies, add this individual to it
                if (compatibility(neatInd, represent) < compatThreshold)
                    {
		    
                    subspecies.get(i).addNewGenIndividual(neatInd);
                    found = true; // change flag
                    break; // search is over, quit loop
                    }
                }
            // if we didn't find a match, create a new subspecies
            if (!found)
                {
		NEATSubspecies newSubspecies = (NEATSubspecies) subspeciesPrototype.emptyClone();
                newSubspecies.reset();
                subspecies.add(newSubspecies);
                newSubspecies.addNewGenIndividual(neatInd);
                }
            }
            

        }

    /** Spawn a new individual with given individual as template. */
    public NEATIndividual spawnWithTemplate(EvolutionState state, NEATSpecies species, int thread, NEATIndividual ind)
        {
        // we clone but do not reset the individual, since these individuals are
        // made from template
        NEATIndividual newInd = (NEATIndividual) ind.clone();
        // for first generation of population, we do not use the weight mutation
        // power from the file
        newInd.mutateLinkWeights(state, species, 1.0, 1.0, MutationType.GAUSSIAN);
        newInd.setGeneration(state);
        newInd.createNetwork(); // we create the network after we have the
        // complete genome
        return newInd;
        }

    /**
     * This function gives a measure of compatibility between two Genomes by
     * computing a linear combination of 3 characterizing variables of their
     * compatibilty. The 3 variables represent PERCENT DISJOINT GENES, PERCENT
     * EXCESS GENES, MUTATIONAL DIFFERENCE WITHIN MATCHING GENES. So the formula
     * for compatibility is:
     * disjointCoeff*numDisjoint+excessCoeff*numExcess+mutdiffCoeff*numMatching.
     */
    public double compatibility(NEATIndividual a, NEATIndividual b)
        {


        // Get the length of the longest Genome for percentage computations
        
        double maxGenomeSize = a.genome.length > b.genome.length ? a.genome.length : b.genome.length;

        int numExcess = 0;
        int numMatching = 0;
        int numDisjoint = 0;
        double mutTotalDiff = 0.0;
        // pointer for two genome
        int i = 0, j = 0;
        while (!(i == a.genome.length && j == b.genome.length))
            {
            // if genome a is already finished, move b's pointer
            if (i == a.genome.length)
                {
                j++;
                numExcess++;
                }
            // if genome b is already finished, move a's pointer
            else if (j == b.genome.length)
                {
                i++;
                numExcess++;
                }
            else
                {
                int aInno = ((NEATGene) a.genome[i]).innovationNumber;
                int bInno = ((NEATGene) b.genome[j]).innovationNumber;
                if (aInno == bInno)
                    {
                    numMatching++;
                    double mutDiff = Math
                        .abs(((NEATGene) a.genome[i]).mutationNumber - ((NEATGene) b.genome[j]).mutationNumber);
                    mutTotalDiff += mutDiff;
                    i++;
                    j++;
                    }
                // innovation number do not match, skip this one
                else if (aInno < bInno)
                    {
                    i++;
                    numDisjoint++;
                    }
                else if (bInno < aInno)
                    {
                    j++;
                    numDisjoint++;
                    }
                }
            }

        // Return the compatibility number using compatibility formula
        // Note that mutTotalDiff/numMatching gives the AVERAGE
        // difference between mutationNums for any two matching Genes
        // in the Genome

        // We do not normalize the terms in here due to the following reason

        // If you decide to use the species compatibility coefficients and
        // thresholds from my own .ne settings files (provided with my NEAT
        // release), then do not normalize the terms in the compatibility
        // function, because I did not do this with my .ne files. In other
        // words, even though my papers suggest normalizing (dividing my number
        // of genes), since I didn't do that the coefficients that I used will
        // not work the same for you if you normalize. If you strongly desire to
        // normalize, you will need to find your own appropriate coefficients
        // and threshold.

        // see the comments above on NEAT page
        // https://www.cs.ucf.edu/~kstanley/neat.html

        // Normalizing for genome size
        // return (disjointCoeff*(numDisjoint/maxGenomeSize)+
        // excessCoeff*(numExcess/maxGenomeSize)+
        // mutDiffCoeff*(mutTotalDiff/numMatching));

        double compatibility = disjointCoeff * (((double) numDisjoint) / 1.0);
        compatibility += excessCoeff * (((double) numExcess) / 1.0);
        compatibility += mutDiffCoeff * (mutTotalDiff / ((double) numMatching));
        
    	

        return compatibility;
        }

    /** Determine the offsprings for all the subspecies. */
    public void countOffspring(EvolutionState state, int subpop)
        {
        // Go through the organisms and add up their adjusted fitnesses to
        // compute the overall average
        double total = 0.0;
        ArrayList<Individual> inds = state.population.subpops.get(subpop).individuals;
        for (int i = 0; i < inds.size(); ++i)
            {
            total += ((NEATIndividual) inds.get(i)).adjustedFitness;

            }

        double overallAverage = total / inds.size();

        // Now compute expected number of offspring for each individual organism
        for (int i = 0; i < inds.size(); ++i)
            {
            ((NEATIndividual) inds.get(i)).expectedOffspring = ((NEATIndividual) inds.get(i)).adjustedFitness
                / overallAverage;


            }

        // Now add those offsprings up within each Subspecies to get the number
        // of
        // offspring per subspecies
        double skim = 0.0;
        int totalExpected = 0;
        for (int i = 0; i < subspecies.size(); ++i)
            {
            NEATSubspecies subs = subspecies.get(i);
            skim = subs.countOffspring(skim);
            totalExpected += subs.expectedOffspring;
            }

       

        // Need to make up for lost floating point precision in offspring
        // assignment. If we lost precision, give an extra baby to the best
        // subpecies
        if (totalExpected < inds.size())
            {
            // Find the subspecies expecting the most
            int maxExpected = 0;
            int finalExpected = 0;
            NEATSubspecies best = null;
            for (int i = 0; i < subspecies.size(); ++i)
                {
                if (subspecies.get(i).expectedOffspring >= maxExpected)
                    {
                    maxExpected = subspecies.get(i).expectedOffspring;
                    best = subspecies.get(i);
                    }
                finalExpected += subspecies.get(i).expectedOffspring;
                }

            // Give the extra offspring to the best subspecies
            best.expectedOffspring++;
            finalExpected++;

            // If we still aren't at total, there is a problem
            // Note that this can happen if a stagnant subpecies
            // dominates the population and then gets killed off by its age
            // Then the whole population plummets in fitness
            // If the average fitness is allowed to hit 0, then we no longer
            // have an average we can use to assign offspring.
            if (finalExpected < inds.size())
                {
                state.output.warnOnce("Population has died");
                for (int i = 0; i < subspecies.size(); ++i)
                    {
                    subspecies.get(i).expectedOffspring = 0;
                    }
                best.expectedOffspring = inds.size();
                }
            }
        }

    /**
     * Breed a new generation of population, this is done by first figure the
     * expected offsprings for each subspecies, and then calls each subspecies
     * to reproduce.
     */
    public void breedNewPopulation(EvolutionState state, int subpop, int thread)
        {

        // see epoch method in Population
        ArrayList<Individual> inds = state.population.subpops.get(subpop).individuals;

        clearEvaluationFlag(inds);

        // clear the innovation information of last generation
        innovations.clear();

        // we also ignore the code for competitive coevolution stagnation
        // detection

        // Use Species' ages to modify the objective fitness of organisms
        // in other words, make it more fair for younger species
        // so they have a chance to take hold
        // Also penalize stagnant species
        // Then adjust the fitness using the species size to "share" fitness
        // within a species.
        // Then, within each Species, mark for death
        // those below survivalThresh * average
        for (int i = 0; i < subspecies.size(); ++i)
            {
            subspecies.get(i).adjustFitness(state, dropoffAge, ageSignificance);
            subspecies.get(i).sortIndividuals();
            subspecies.get(i).updateSubspeceisMaxFitness();
            subspecies.get(i).markReproducableIndividuals(survivalThreshold);
            }

        // count the offspring for each subspecies
        countOffspring(state, subpop);

        // sort the subspecies use extra list based on the max fitness
        // these need to use original fitness, descending order
        ArrayList<NEATSubspecies> sortedSubspecies = new ArrayList<NEATSubspecies>(subspecies);
        Collections.sort(sortedSubspecies, new Comparator<NEATSubspecies>()
                {
                @Override
                    public int compare(NEATSubspecies o1, NEATSubspecies o2)
                    {
                    NEATIndividual ind1 = (NEATIndividual) o1.individuals.get(0);
                    NEATIndividual ind2 = (NEATIndividual) o2.individuals.get(0);

                    if (ind1.fitness.fitness() < ind2.fitness.fitness())
                        return 1;
                    if (ind1.fitness.fitness() > ind2.fitness.fitness())
                        return -1;
                    return 0;
                    }
                });

        
        int bestSpecieNum = sortedSubspecies.get(0).id;

        // Check for population-level stagnation code
        populationStagnation(state, subpop, sortedSubspecies);

        // Check for stagnation if there is stagnation, perform delta-coding
        // TODO: fix weird constant
        if (highestLastChanged >= dropoffAge + 5)
            {
            deltaCoding(state, subpop, sortedSubspecies);
            }
        // STOLEN BABIES: The system can take expected offspring away from
        // worse species and give them to superior species depending on
        // the system parameter babies_stolen (when babies_stolen > 0)
        else if (babiesStolen > 0)
            {
            stealBabies(state, subpop, sortedSubspecies);
            }

        // Kill off all Individual marked for death. The remainder
        // will be allowed to reproduce.
        // NOTE this result the size change of individuals in each subspecies
        // however, it doesn't effect the individuals for the whole neat
        // population
        for (int i = 0; i < sortedSubspecies.size(); ++i)
            {
            sortedSubspecies.get(i).removePoorFitnessIndividuals();
            }

        // Reproduction
        // Perform reproduction. Reproduction is done on a per-Species
        // basis. (So this could be paralellized potentially.)
        // we do this with sortedSubspecies instead of subspecies
        // this is due to the fact that new subspecies could be created during
        // the reproduction period
        // thus, the sortedSubspecies are guarantee to contain all the old
        // subspecies
        for (int i = 0; i < sortedSubspecies.size(); ++i)
            {
            // first for all current subspecies, clear their new generation
            // individuals
            NEATSubspecies subs = sortedSubspecies.get(i);
            subs.newGenIndividuals.clear();
            }

        for (int i = 0; i < sortedSubspecies.size(); ++i)
            {
            NEATSubspecies subs = sortedSubspecies.get(i);
            subs.reproduce(state, thread, subpop, sortedSubspecies);
            }

        // Remove all empty subspecies and age ones that survive
        // As this happens, create master individuals list for the new
        // generation

        // first age the old subspecies
        for (int i = 0; i < sortedSubspecies.size(); ++i)
            {
            NEATSubspecies subs = sortedSubspecies.get(i);
            subs.age++;
            }
        ArrayList<NEATSubspecies> remainSubspecies = new ArrayList<NEATSubspecies>();
        ArrayList<Individual> newGenIndividuals = new ArrayList<Individual>();
        for (int i = 0; i < subspecies.size(); ++i)
            {
            if (subspecies.get(i).hasNewGeneration())
                {
                // add to the remain subspecies
                remainSubspecies.add(subspecies.get(i));
                subspecies.get(i).toNewGeneration();
                // add to the new generation population
                newGenIndividuals.addAll(subspecies.get(i).individuals);
                }
            }
        // replace the old stuff
        subspecies = remainSubspecies;

                state.population.subpops.get(subpop).individuals = newGenIndividuals;
        // assign the individuals with new id
        assignIndividualsId(state.population.subpops.get(subpop).individuals);

        }

    /** Perform a delta coding. */
    public void deltaCoding(EvolutionState state, int subpop, ArrayList<NEATSubspecies> sortedSubspecies)
        {
        highestLastChanged = 0;

        int popSize = state.population.subpops.get(subpop).initialSize;
        int halfPop = popSize / 2;

        NEATSubspecies bestFitnessSubspecies = sortedSubspecies.get(0);
        // the first individual of the first subspecies can have 1/2 pop size
        // offsprings
        ((NEATIndividual) bestFitnessSubspecies.first()).superChampionOffspring = halfPop;
        // the first subspecies can have 1/2 pop size offspring
        bestFitnessSubspecies.expectedOffspring = halfPop;
        bestFitnessSubspecies.ageOfLastImprovement = bestFitnessSubspecies.age;

        if (sortedSubspecies.size() >= 2)
            {
            // the second subspecies can have the other half pop size
            ((NEATIndividual) sortedSubspecies.get(1).first()).superChampionOffspring = popSize - halfPop;
            sortedSubspecies.get(1).expectedOffspring = popSize - halfPop;
            sortedSubspecies.get(1).ageOfLastImprovement = sortedSubspecies.get(1).age;
            // the remainder subspecies has 0 offsprings
            for (int i = 2; i < sortedSubspecies.size(); ++i)
                {
                sortedSubspecies.get(i).expectedOffspring = 0;
                }
            }
        else
            {
            ((NEATIndividual) bestFitnessSubspecies.first()).superChampionOffspring += popSize - halfPop;
            bestFitnessSubspecies.expectedOffspring = popSize - halfPop;
            }
        }

    /** Determine if the whole subpopulation get into stagnation. */
    public void populationStagnation(EvolutionState state, int subpop, ArrayList<NEATSubspecies> sortedSubspecies)
        {
        NEATIndividual bestFitnessIndividual = (NEATIndividual) sortedSubspecies.get(0).individuals.get(0);
        bestFitnessIndividual.popChampion = true;
        if (bestFitnessIndividual.fitness.fitness() > highestFitness)
            {
            highestFitness = bestFitnessIndividual.fitness.fitness();
            highestLastChanged = 0;
            state.output.message("Population has reached a new RECORD FITNESS " + highestFitness);
            }
        else
            {
            highestLastChanged++;
            state.output.message(
                highestLastChanged + " generations since last population fitness record " + highestFitness);
            }
        }

    /** Steal the babies from champion subspecies. */
    public void stealBabies(EvolutionState state, int subpop, ArrayList<NEATSubspecies> sortedSubspecies)
        {
        // Take away a constant number of expected offspring from the worst few
        // species
        int babiesAlreadyStolen = 0;

        for (int i = sortedSubspecies.size() - 1; i >= 0 && babiesAlreadyStolen < babiesStolen; i--)
            {
            NEATSubspecies subs = sortedSubspecies.get(i);

            if (subs.age > 5 && subs.expectedOffspring > 2)
                {
                // This subspecies has enough to finish off the stolen pool
                int babiesNeeded = babiesStolen - babiesAlreadyStolen;
                if (subs.expectedOffspring - 1 >= babiesNeeded)
                    {
                    subs.expectedOffspring -= babiesNeeded;
                    babiesAlreadyStolen = babiesStolen;
                    }
                // Not enough here to complete the pool of stolen, then leave
                // one individual
                // for that subspecies
                else
                    {
                    babiesAlreadyStolen += subs.expectedOffspring - 1;
                    subs.expectedOffspring = 1;
                    }
                }
            }

        // Mark the best champions of the top subspecies to be the super
        // champions
        // who will take on the extra offspring for cloning or mutant cloning
        // Determine the exact number that will be given to the top three
        // They get, in order, 1/5 1/5 and 1/10 of the already stolen babies
        int[] quote = new int[3];
        quote[0] = quote[1] = babiesStolen / 5;
        quote[2] = babiesStolen / 10;

        boolean done = false;
        int quoteIndex = 0;
        Iterator<NEATSubspecies> iterator = sortedSubspecies.iterator();

        while (!done && iterator.hasNext())
            {
            NEATSubspecies subs = iterator.next();
            // Don't give to dying species even if they are champions
            if (subs.timeSinceLastImproved() <= dropoffAge)
                {
                if (quoteIndex < quote.length)
                    {
                    if (babiesAlreadyStolen > quote[quoteIndex])
                        {
                        ((NEATIndividual) subs.first()).superChampionOffspring = quote[quoteIndex];
                        subs.expectedOffspring += quote[quoteIndex];
                        babiesAlreadyStolen -= quote[quoteIndex];
                        }
                    quoteIndex++;
                    }
                else if (quoteIndex >= quote.length)
                    {
                    // Randomize a little which species get boosted by a super
                    // champion
                    if (state.random[0].nextDouble() > 0.1)
                        {
                        if (babiesAlreadyStolen > 3)
                            {
                            ((NEATIndividual) subs.first()).superChampionOffspring = 3;
                            subs.expectedOffspring += 3;
                            babiesAlreadyStolen -= 3;
                            }
                        else
                            {
                            ((NEATIndividual) subs.first()).superChampionOffspring = babiesAlreadyStolen;
                            subs.expectedOffspring += babiesAlreadyStolen;
                            babiesAlreadyStolen = 0;
                            }
                        }
                    }
                // assiged all the stolen babies
                if (babiesAlreadyStolen == 0)
                    done = true;
                }
            }

        // If any stolen babies aren't taken, give them to species #1's champion
        if (babiesAlreadyStolen > 0)
            {
            state.output.message("Not all stolen babies assigned, giving to the best subspecies");
            NEATSubspecies subs = subspecies.get(0);
            ((NEATIndividual) subs.first()).superChampionOffspring += babiesAlreadyStolen;
            subs.expectedOffspring += babiesAlreadyStolen;
            babiesAlreadyStolen = 0;
            }

        }

    /**
     * We use id as the unique identity for each individual, here we assign id
     * to them, always start with 0
     */
    public void assignIndividualsId(ArrayList<Individual> individuals)
        {
        for (int i = 0; i < individuals.size(); ++i)
            {
            ((NEATIndividual) individuals.get(i)).setId(i);
            }

        }

    /** Create a new individual with given nodes and genes */
    public Individual newIndividual(final EvolutionState state, int thread, ArrayList<NEATNode> nodes,
        ArrayList<Gene> genes)
        {
        NEATIndividual newind = (NEATIndividual) (super.newIndividual(state, thread));
        newind.reset(nodes, genes);
        return newind;
        }

    public boolean hasInnovation(NEATInnovation inno)
        {
        return innovations.containsKey(inno);
        }

    public NEATInnovation getInnovation(NEATInnovation inno)
        {
        return innovations.get(inno);
        }

    public void addInnovation(NEATInnovation inno)
        {
        innovations.put(inno, inno);
        }

    /**
     * Clear the evaluation flag in each individual. This is important if a
     * evaluation individual mutated.
     */
    public void clearEvaluationFlag(ArrayList<Individual> individuals)
        {
        for (int i = 0; i < individuals.size(); ++i)
            {
            individuals.get(i).evaluated = false;
            }
        }

    public double randomFloat(EvolutionState state)
        {
        return state.random[0].nextDouble();
        }

    // FIXME: after we verify the algorithm is correct, we could change this to
    // use nextBoolean
    public int randomSign(EvolutionState state)
        {
        int n = state.random[0].nextInt();
        if (n % 2 == 0)
            return -1;
        else
            return 1;
        }

    }
